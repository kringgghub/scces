import { auth, db } from '../firebase.js';
import { onAuthStateChanged, signOut } from 'https://www.gstatic.com/firebasejs/13.4.0/firebase-auth.js';
import { doc, getDoc, updateDoc, serverTimestamp } from 'https://www.gstatic.com/firebasejs/13.4.0/firebase-firestore.js';

const STORAGE_KEYS = {
  VOTES: "scces_votes_2026",
  VOTED_IDS: "scces_voted_ids_2026",
  RECEIPTS: "scces_receipts_2026",
  TOTAL_BALLOTS: "scces_total_ballots_2026"
};

const CURRENT_STUDENT_KEY = "studentPortalCurrentUser";
const STUDENT_ACCOUNTS_KEY = "studentPortalAccounts";
const LOGIN_PAGE_PATH = "../login/login.html";

let activeStudent = null;

// Load the authenticated student profile from Firestore. No demo-user fallback is allowed.
async function loadCurrentStudent() {
  const user = auth.currentUser;
  if (!user) throw new Error("You must sign in first.");
  const profileSnap = await getDoc(doc(db, "students", user.uid));
  if (!profileSnap.exists() || profileSnap.data().role !== "student") {
    throw new Error("A valid student profile was not found.");
  }
  activeStudent = { ...profileSnap.data(), birthdate: profileSnap.data().birthDate || "", uid: user.uid };
}

// Persist editable student profile fields to Firestore.
async function persistStudentUpdates() {
  if (!activeStudent?.uid) return;
  await updateDoc(doc(db, "students", activeStudent.uid), {
    name: activeStudent.name, contactNumber: activeStudent.contactNumber,
    emergencyNumber: activeStudent.emergencyNumber, address: activeStudent.address,
    birthDate: activeStudent.birthdate || "", updatedAt: serverTimestamp()
  });
}

// 2. Initialize Baseline Tallies
function initElectionData() {
  if (!localStorage.getItem(STORAGE_KEYS.VOTES)) {
    const votes = {};
    ELECTION_POSITIONS.forEach(pos => pos.candidates.forEach(candidate => { votes[candidate.id] = 0; }));
    // These local values are for interface preview only, not certified election data.
    localStorage.setItem(STORAGE_KEYS.VOTES, JSON.stringify(votes));
    localStorage.setItem(STORAGE_KEYS.VOTED_IDS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.RECEIPTS, JSON.stringify({}));
    localStorage.setItem(STORAGE_KEYS.TOTAL_BALLOTS, "0");
  }
}

function getVotes() {
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.VOTES)) || {};
}

function getVotedIds() {
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.VOTED_IDS)) || [];
}

function getReceipts() {
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.RECEIPTS)) || {};
}

function hasStudentVoted() {
  return getVotedIds().includes(activeStudent.studentId);
}

// 3. Populate User Identity & Dashboard Cards
function renderUserIdentity() {
  const firstName = activeStudent.name.split(" ")[0];
  document.getElementById("welcome-first-name").textContent = firstName;
  document.getElementById("ballot-voter-label").textContent = `${activeStudent.name} (${activeStudent.studentId})`;

  const totalBallots = localStorage.getItem(STORAGE_KEYS.TOTAL_BALLOTS) || "80";
  const resultsTotalEl = document.getElementById("results-total-ballots");
  if (resultsTotalEl) resultsTotalEl.textContent = totalBallots;

  // Update the clickable Voting Status strip card
  const statusLabel = document.getElementById("dash-voting-status-label");
  const statusIcon = document.getElementById("dash-status-icon");
  if (hasStudentVoted()) {
    statusLabel.textContent = "Ballot Submitted ✓";
    statusLabel.style.color = "var(--success-green)";
    statusIcon.classList.add("voted");
  } else {
    statusLabel.textContent = "Not Yet Voted";
    statusLabel.style.color = "var(--purple-primary)";
    statusIcon.classList.remove("voted");
  }
}

// 4. Live Countdown Timer
function startCountdown() {
  const targetDate = new Date("November 30, 2026 23:59:59").getTime();

  function tick() {
    const now = Date.now();
    const diff = Math.max(0, targetDate - now);

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const mins = Math.floor((diff / (1000 * 60)) % 60);
    const secs = Math.floor((diff / 1000) % 60);

    document.getElementById("cd-days").textContent = String(days).padStart(2, "0");
    document.getElementById("cd-hours").textContent = String(hours).padStart(2, "0");
    document.getElementById("cd-mins").textContent = String(mins).padStart(2, "0");
    document.getElementById("cd-secs").textContent = String(secs).padStart(2, "0");
  }

  tick();
  setInterval(tick, 1000);
}

// 5. Navigation & Interactive Cards Setup
function switchView(viewName) {
  document.querySelectorAll(".nav-item[data-view]").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.view === viewName);
  });

  document.querySelectorAll(".view-section").forEach(section => {
    section.classList.toggle("active", section.id === `view-${viewName}`);
  });

  if (viewName === "ballot") renderBallotView();
  if (viewName === "status") renderStatusPage();
  if (viewName === "results") renderResultsView();
  if (viewName === "profile") renderProfileView();
}

function setupNavigation() {
  document.querySelectorAll(".nav-item[data-view]").forEach(btn => {
    btn.addEventListener("click", () => switchView(btn.dataset.view));
  });

  document.getElementById("featured-view-all-btn").addEventListener("click", () => {
    switchView("candidates");
  });

  // WELCOME BANNER ("Hello, {Name}! Welcome to the Student Council Election System") -> Opens Student Info + Inline Editor
  document.getElementById("banner-student-info").addEventListener("click", openStudentInfoModal);

  // CARD 1: Voting Status Box -> Shows Student's Voting Status
  document.getElementById("card-voting-status").addEventListener("click", openVotingStatusModal);

  // CARD 2: Ballot Security Box -> Shows 1 ID = 1 Vote, Election Schedule, and Security Rules
  document.getElementById("card-ballot-security").addEventListener("click", openBallotSecurityModal);

  // Logout Button -> redirects to ../login/login.html
  document.getElementById("logout-btn").addEventListener("click", async () => {
    await signOut(auth);
    showToast("Logging out...");
    setTimeout(() => window.location.replace(LOGIN_PAGE_PATH), 400);
  });
}

// 6. INTERACTIVE MODAL 1: STUDENT INFORMATION (Triggered from Welcome Banner)
function openStudentInfoModal() {
  const editableFields = [
    { key: "contactNumber", label: "Contact Number", type: "tel" },
    { key: "emergencyNumber", label: "Emergency Number", type: "tel" },
    { key: "birthdate", label: "Birthdate", type: "date" },
    { key: "address", label: "Address", type: "text" }
  ];

  const renderModalContent = () => {
    const editableHtml = editableFields
      .map(
        f => `
        <div class="profile-field editable-field" data-edit-key="${f.key}" data-input-type="${f.type}" title="Click to edit ${f.label}">
          <span>
            ${f.label}
            <em class="edit-badge"><i class="fa-solid fa-pen"></i> Edit</em>
          </span>
          <strong id="val-${f.key}">${activeStudent[f.key] || "Not provided"}</strong>
          <div class="inline-edit-box hidden" id="editor-${f.key}">
            <input type="${f.type}" class="inline-edit-input" id="input-${f.key}" value="${activeStudent[f.key] || ""}" />
            <div class="inline-edit-actions">
              <button type="button" class="btn-mini-save" data-save-key="${f.key}">Save</button>
              <button type="button" class="btn-mini-cancel" data-cancel-key="${f.key}">Cancel</button>
            </div>
          </div>
        </div>
      `
      )
      .join("");

    document.getElementById("modal-body-content").innerHTML = `
      <div style="display: flex; align-items: center; gap: 14px; margin-bottom: 14px;">
        <div class="cand-avatar-md" style="width: 54px; height: 54px; font-size: 1.2rem;">
          ${activeStudent.name.slice(0, 2).toUpperCase()}
        </div>
        <div>
          <h3 style="font-size: 1.2rem; color: var(--sidebar-deep);">Student Registration Information</h3>
          <p style="font-size: 0.82rem; color: var(--text-muted);">
            Select <strong>Contact Number, Emergency Number, Birthdate, Address,</strong> or <strong>Email</strong> to edit.
          </p>
        </div>
      </div>

      <div class="profile-grid">
        <div class="profile-field">
          <span>Full Name</span>
          <strong>${activeStudent.name}</strong>
        </div>
        <div class="profile-field">
          <span>Student ID</span>
          <strong>${activeStudent.studentId}</strong>
        </div>
        <div class="profile-field">
          <span>College / Department</span>
          <strong>${activeStudent.department || "CICS"}</strong>
        </div>
        <div class="profile-field">
          <span>Course &amp; Section</span>
          <strong>${activeStudent.course || "BSIT"} • ${activeStudent.yearSection || "3A"}</strong>
        </div>
        ${editableHtml}
      </div>
    `;

    // Attach click-to-edit listeners
    document.querySelectorAll("#modal-body-content .editable-field").forEach(card => {
      card.addEventListener("click", e => {
        if (e.target.closest(".inline-edit-box")) return;
        const key = card.dataset.editKey;
        document.getElementById(`val-${key}`).classList.add("hidden");
        document.getElementById(`editor-${key}`).classList.remove("hidden");
        document.getElementById(`input-${key}`).focus();
      });
    });

    document.querySelectorAll("#modal-body-content [data-save-key]").forEach(btn => {
      btn.addEventListener("click", e => {
        e.stopPropagation();
        const key = btn.dataset.saveKey;
        const newVal = document.getElementById(`input-${key}`).value.trim();
        if (!newVal) {
          showToast("Field cannot be empty.");
          return;
        }
        activeStudent[key] = newVal;
        persistStudentUpdates().catch(error => showToast(error.message || "Profile update failed."));
        renderModalContent();
        if (document.getElementById("view-profile").classList.contains("active")) {
          renderProfileView();
        }
        showToast("Student information updated!");
      });
    });

    document.querySelectorAll("#modal-body-content [data-cancel-key]").forEach(btn => {
      btn.addEventListener("click", e => {
        e.stopPropagation();
        const key = btn.dataset.cancelKey;
        document.getElementById(`editor-${key}`).classList.add("hidden");
        document.getElementById(`val-${key}`).classList.remove("hidden");
      });
    });
  };

  renderModalContent();
  document.getElementById("universal-modal").classList.remove("hidden");
}

// 7. INTERACTIVE MODAL 2: VOTING STATUS POPUP
function openVotingStatusModal() {
  const receipts = getReceipts();
  const myReceipt = receipts[activeStudent.studentId];

  if (hasStudentVoted()) {
    document.getElementById("modal-body-content").innerHTML = `
      <div style="text-align: center;">
        <div class="ballot-badge-circle voted"><i class="fa-solid fa-check"></i></div>
        <h3 style="color: var(--success-green); font-size: 1.25rem;">Voting Status: Ballot Submitted</h3>
        <p style="font-size: 0.88rem; color: var(--text-muted); margin-top: 4px;">
          Student ID <strong>${activeStudent.studentId}</strong> has already cast an official ballot.
        </p>
        <div class="receipt-box">
          <p><strong>Voter:</strong> ${activeStudent.name}</p>
          ${myReceipt ? `<p><strong>Reference Code:</strong> ${myReceipt.referenceCode}</p>` : ""}
          ${myReceipt ? `<p><strong>Date &amp; Time Cast:</strong> ${myReceipt.timestamp}</p>` : ""}
        </div>
      </div>
    `;
  } else {
    document.getElementById("modal-body-content").innerHTML = `
      <div style="text-align: center; padding: 8px 0;">
        <div class="ballot-badge-circle"><i class="fa-solid fa-box-archive"></i></div>
        <h3 style="color: var(--purple-primary); font-size: 1.25rem;">Voting Status: Not Yet Voted</h3>
        <p style="font-size: 0.9rem; color: var(--text-muted); margin: 8px 0 18px;">
          Hello <strong>${activeStudent.name}</strong> (${activeStudent.studentId}), your ballot is still open. Cast your vote before <strong>Nov 30, 2026 • 11:59 PM</strong>.
        </p>
        <button type="button" class="btn-cta-full" id="modal-go-vote-btn">
          <i class="fa-solid fa-check-to-slot"></i> Go to Official Ballot
        </button>
      </div>
    `;
    document.getElementById("modal-go-vote-btn").addEventListener("click", () => {
      document.getElementById("universal-modal").classList.add("hidden");
      switchView("ballot");
    });
  }

  document.getElementById("universal-modal").classList.remove("hidden");
}

// 8. INTERACTIVE MODAL 3: BALLOT SECURITY & ELECTION SCHEDULE
function openBallotSecurityModal() {
  document.getElementById("modal-body-content").innerHTML = `
    <div>
      <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
        <div class="metric-icon"><i class="fa-solid fa-shield-halved"></i></div>
        <div>
          <h3 style="font-size: 1.22rem; color: var(--sidebar-deep);">Ballot Security &amp; Election Schedule</h3>
          <span style="font-size: 0.82rem; color: var(--text-muted);">Official SCCES Integrity Guidelines</span>
        </div>
      </div>

      <ul class="security-list">
        <li>
          <i class="fa-solid fa-user-lock"></i>
          <div>
            <strong>1 ID = 1 Vote Strict Enforcement</strong>
            <p style="font-size: 0.84rem; color: var(--text-secondary);">
              Each verified Student ID (<strong>${activeStudent.studentId}</strong>) is permitted exactly one official ballot submission. Once submitted, the ballot locks permanently to prevent duplicate voting.
            </p>
          </div>
        </li>
        <li>
          <i class="fa-regular fa-calendar-check"></i>
          <div>
            <strong>Official Election Period &amp; Deadline</strong>
            <p style="font-size: 0.84rem; color: var(--text-secondary);">
              <strong>Election Opens:</strong> November 15, 2026 at 8:00 AM<br />
              <strong>Election Ends:</strong> November 30, 2026 at 11:59 PM (Polls automatically lock at deadline)
            </p>
          </div>
        </li>
        <li>
          <i class="fa-solid fa-receipt"></i>
          <div>
            <strong>Verifiable Digital Receipt &amp; Ballot Secrecy</strong>
            <p style="font-size: 0.84rem; color: var(--text-secondary);">
              Every submitted ballot generates a unique <code>SCCES-XXXXXX</code> confirmation code while separating voter identity from public tally counters.
            </p>
          </div>
        </li>
        <li>
          <i class="fa-solid fa-database"></i>
          <div>
            <strong>Tamper-Resistant Tally Auditing</strong>
            <p style="font-size: 0.84rem; color: var(--text-secondary);">
              All vote increments are validated per office before updating live certified election results.
            </p>
          </div>
        </li>
      </ul>
    </div>
  `;

  document.getElementById("universal-modal").classList.remove("hidden");
}

// 9. Dashboard Featured Candidates & Voting Status Widget
function renderDashboardWidgets() {
  const featuredContainer = document.getElementById("featured-candidates-grid");
  const featuredList = [];

  ELECTION_POSITIONS.forEach(pos => {
    const feat = pos.candidates.find(c => c.featured) || pos.candidates[0];
    featuredList.push({ ...feat, positionTitle: pos.title, positionId: pos.id });
  });

  featuredContainer.innerHTML = featuredList
    .map(
      cand => `
      <div class="featured-cand-card">
        <div>
          <div class="cand-portrait">${cand.initials}</div>
          <h4>${cand.name}</h4>
          <span class="cand-role-label">${cand.positionTitle}</span>
          <span class="party-pill">${cand.party}</span>
        </div>
        <button type="button" class="btn-purple-sm" onclick="openCandidateModal('${cand.positionId}', '${cand.id}')">
          View Profile
        </button>
      </div>
    `
    )
    .join("");

  const statusBox = document.getElementById("dash-voting-status-box");
  if (hasStudentVoted()) {
    statusBox.innerHTML = `
      <div class="ballot-badge-circle voted">
        <i class="fa-solid fa-check"></i>
      </div>
      <h4 class="voted-title">Ballot Submitted</h4>
      <p>Your vote has been securely recorded for the 2026 election.</p>
      <button type="button" class="btn-cta-full" id="dash-view-receipt-btn">
        <i class="fa-solid fa-receipt"></i> View Voting Receipt
      </button>
    `;
    document.getElementById("dash-view-receipt-btn").addEventListener("click", () => {
      switchView("status");
    });
  } else {
    statusBox.innerHTML = `
      <div class="ballot-badge-circle">
        <i class="fa-solid fa-box-archive"></i>
      </div>
      <h4>Not Yet Voted</h4>
      <p>You haven't cast your vote yet. Make your voice count!</p>
      <button type="button" class="btn-cta-full" id="dash-cast-vote-btn">
        <i class="fa-solid fa-check-to-slot"></i> Cast Your Vote <i class="fa-solid fa-arrow-right"></i>
      </button>
    `;
    document.getElementById("dash-cast-vote-btn").addEventListener("click", () => {
      switchView("ballot");
    });
  }
}

// 10. Full Candidates & Platforms View
function renderAllCandidates(filterPos = "all") {
  const select = document.getElementById("position-filter");
  if (select.options.length === 1) {
    ELECTION_POSITIONS.forEach(pos => {
      select.add(new Option(pos.title, pos.id));
    });
    select.addEventListener("change", e => renderAllCandidates(e.target.value));
  }

  const container = document.getElementById("all-candidates-container");
  const positionsToRender =
    filterPos === "all"
      ? ELECTION_POSITIONS
      : ELECTION_POSITIONS.filter(p => p.id === filterPos);

  container.innerHTML = positionsToRender
    .map(
      pos => `
      <div class="position-box">
        <div class="position-box-header">
          <h3>${pos.title}</h3>
          <span>${pos.subtitle}</span>
        </div>
        <div class="candidates-list-grid">
          ${pos.candidates
            .map(
              cand => `
              <article class="cand-detail-card">
                <div>
                  <div class="cand-top-row">
                    <div class="cand-avatar-md">${cand.initials}</div>
                    <div>
                      <h4>${cand.name}</h4>
                      <span style="font-size: 0.78rem; color: var(--text-muted); display: block;">${cand.grade}</span>
                      <span class="party-pill" style="margin: 4px 0 0;">${cand.party}</span>
                    </div>
                  </div>
                  <p class="cand-quote">"${cand.slogan}"</p>
                  <ul class="cand-bullets">
                    ${cand.platform.map(item => `<li>${item}</li>`).join("")}
                  </ul>
                </div>
                <button type="button" class="btn-purple-sm" onclick="openCandidateModal('${pos.id}', '${cand.id}')">
                  View Full Profile &amp; Bio
                </button>
              </article>
            `
            )
            .join("")}
        </div>
      </div>
    `
    )
    .join("");
}

// 11. Candidate Modal
function openCandidateModal(positionId, candidateId) {
  const pos = ELECTION_POSITIONS.find(p => p.id === positionId);
  const cand = pos.candidates.find(c => c.id === candidateId);

  document.getElementById("modal-body-content").innerHTML = `
    <div class="cand-top-row" style="margin-bottom: 14px;">
      <div class="cand-avatar-md" style="width: 60px; height: 60px; font-size: 1.25rem;">${cand.initials}</div>
      <div>
        <h3 style="font-size: 1.25rem; color: var(--sidebar-deep);">${cand.name}</h3>
        <span style="font-size: 0.85rem; color: var(--text-muted); display: block;">
          Candidate for <strong>${pos.title}</strong> • ${cand.grade}
        </span>
        <span class="party-pill" style="margin-top: 5px;">${cand.party}</span>
      </div>
    </div>
    <p class="cand-quote" style="font-size: 0.92rem;">"${cand.slogan}"</p>
    <h4 style="margin: 14px 0 6px; color: var(--purple-primary);">Candidate Biography</h4>
    <p style="font-size: 0.9rem; color: var(--text-secondary);">${cand.bio}</p>
    <h4 style="margin: 14px 0 8px; color: var(--purple-primary);">Platform &amp; Action Agenda</h4>
    <ul class="cand-bullets" style="font-size: 0.9rem;">
      ${cand.platform.map(p => `<li>${p}</li>`).join("")}
    </ul>
  `;

  document.getElementById("universal-modal").classList.remove("hidden");
}

function setupModal() {
  const closeModal = () => document.getElementById("universal-modal").classList.add("hidden");
  document.getElementById("modal-close-btn").addEventListener("click", closeModal);
  document.getElementById("modal-backdrop").addEventListener("click", closeModal);
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") closeModal();
  });
}

// 12. Cast Vote Ballot View
function renderBallotView() {
  const container = document.getElementById("ballot-container");

  if (hasStudentVoted()) {
    container.innerHTML = `
      <div class="panel-card" style="text-align: center; padding: 36px 24px;">
        <div class="ballot-badge-circle voted"><i class="fa-solid fa-check"></i></div>
        <h3 style="color: var(--success-green); font-size: 1.3rem;">You Have Already Voted</h3>
        <p style="color: var(--text-muted); max-width: 460px; margin: 8px auto 18px;">
          Student ID <strong>${activeStudent.studentId}</strong> has already submitted an official ballot. Duplicate voting is locked.
        </p>
        <button type="button" class="btn-submit-ballot" id="go-to-results-btn">
          View Live Election Results
        </button>
      </div>
    `;
    document.getElementById("go-to-results-btn").addEventListener("click", () => switchView("results"));
    return;
  }

  container.innerHTML = `
    <form id="official-ballot-form" class="positions-stack">
      ${ELECTION_POSITIONS.map(
        pos => `
        <div class="position-box">
          <div class="position-box-header">
            <h3>${pos.title}</h3>
            <span>Select one (1) candidate</span>
          </div>
          ${pos.candidates
            .map(
              cand => `
              <label class="ballot-choice" data-group="${pos.id}">
                <input type="radio" name="${pos.id}" value="${cand.id}" required />
                <div>
                  <strong>${cand.name}</strong>
                  <span style="color: var(--purple-primary); font-size: 0.82rem; font-weight: 700;">
                    (${cand.party})
                  </span>
                  <div style="font-size: 0.82rem; color: var(--text-muted);">${cand.slogan}</div>
                </div>
              </label>
            `
            )
            .join("")}
        </div>
      `
      ).join("")}
      <div class="ballot-submit-bar">
        <button type="submit" class="btn-submit-ballot">
          <i class="fa-solid fa-paper-plane"></i> Submit Official Ballot
        </button>
      </div>
    </form>
  `;

  const form = document.getElementById("official-ballot-form");

  form.querySelectorAll('input[type="radio"]').forEach(radio => {
    radio.addEventListener("change", e => {
      const group = e.target.name;
      form.querySelectorAll(`.ballot-choice[data-group="${group}"]`).forEach(el => {
        el.classList.remove("selected");
      });
      e.target.closest(".ballot-choice").classList.add("selected");
    });
  });

  form.addEventListener("submit", e => {
    e.preventDefault();
    showToast("Official voting is not enabled yet. This Spark version is for login and admin-data testing only.");
    return;

    const votes = getVotes();
    const votedIds = getVotedIds();
    const receipts = getReceipts();
    const choicesSummary = [];

    ELECTION_POSITIONS.forEach(pos => {
      const checked = form.querySelector(`input[name="${pos.id}"]:checked`);
      if (checked) {
        const candId = checked.value;
        votes[candId] = (votes[candId] || 0) + 1;
        const candObj = pos.candidates.find(c => c.id === candId);
        choicesSummary.push({ position: pos.title, candidate: candObj.name, party: candObj.party });
      }
    });

    votedIds.push(activeStudent.studentId);
    const newTurnout = parseInt(localStorage.getItem(STORAGE_KEYS.TOTAL_BALLOTS) || "80", 10) + 1;

    receipts[activeStudent.studentId] = {
      referenceCode: "SCCES-" + Math.floor(100000 + Math.random() * 900000),
      timestamp: new Date().toLocaleString(),
      choices: choicesSummary
    };

    localStorage.setItem(STORAGE_KEYS.VOTES, JSON.stringify(votes));
    localStorage.setItem(STORAGE_KEYS.VOTED_IDS, JSON.stringify(votedIds));
    localStorage.setItem(STORAGE_KEYS.RECEIPTS, JSON.stringify(receipts));
    localStorage.setItem(STORAGE_KEYS.TOTAL_BALLOTS, String(newTurnout));

    renderUserIdentity();
    renderDashboardWidgets();
    showToast("Official ballot submitted successfully!");
    switchView("status");
  });
}

// 13. Voting Status & Receipt View
function renderStatusPage() {
  const container = document.getElementById("status-page-container");
  const receipts = getReceipts();
  const myReceipt = receipts[activeStudent.studentId];

  if (hasStudentVoted()) {
    const choicesHtml = myReceipt
      ? myReceipt.choices
          .map(
            c =>
              `<p style="margin-top: 6px;"><strong>${c.position}:</strong> ${c.candidate} <span style="color: var(--purple-primary);">(${c.party})</span></p>`
          )
          .join("")
      : `<p style="margin-top: 6px;">Ballot recorded for Student ID <strong>${activeStudent.studentId}</strong>.</p>`;

    container.innerHTML = `
      <div style="text-align: center; max-width: 560px; margin: 0 auto;">
        <div class="ballot-badge-circle voted"><i class="fa-solid fa-check"></i></div>
        <h3 style="color: var(--success-green); font-size: 1.35rem;">Official Vote Verified</h3>
        <p style="color: var(--text-muted); font-size: 0.9rem;">
          Thank you for participating in the 2026–2027 Student Council Elections.
        </p>
        <div class="receipt-box">
          <p><strong>Voter Name:</strong> ${activeStudent.name}</p>
          <p><strong>Student ID:</strong> ${activeStudent.studentId}</p>
          ${myReceipt ? `<p><strong>Receipt Ref #:</strong> ${myReceipt.referenceCode}</p>` : ""}
          ${myReceipt ? `<p><strong>Submitted On:</strong> ${myReceipt.timestamp}</p>` : ""}
          <hr style="border: none; border-top: 1px solid var(--purple-border); margin: 10px 0;" />
          ${choicesHtml}
        </div>
        <button type="button" class="btn-submit-ballot" style="margin-top: 18px;" id="status-to-results-btn">
          View Live Election Results
        </button>
      </div>
    `;
    document.getElementById("status-to-results-btn").addEventListener("click", () => switchView("results"));
  } else {
    container.innerHTML = `
      <div style="text-align: center; max-width: 480px; margin: 0 auto; padding: 14px 0;">
        <div class="ballot-badge-circle"><i class="fa-solid fa-box-archive"></i></div>
        <h3 style="color: var(--purple-primary); font-size: 1.3rem;">Status: Not Yet Voted</h3>
        <p style="color: var(--text-muted); margin: 8px 0 18px; font-size: 0.9rem;">
          Your Student ID (<strong>${activeStudent.studentId}</strong>) is eligible to vote. Proceed to the official ballot to submit your choices.
        </p>
        <button type="button" class="btn-submit-ballot" id="status-to-ballot-btn">
          Proceed to Official Ballot
        </button>
      </div>
    `;
    document.getElementById("status-to-ballot-btn").addEventListener("click", () => switchView("ballot"));
  }
}

// 14. Live Election Results View
function renderResultsView() {
  const votes = getVotes();
  const totalBallots = localStorage.getItem(STORAGE_KEYS.TOTAL_BALLOTS) || "80";
  document.getElementById("results-total-ballots").textContent = totalBallots;

  const container = document.getElementById("results-container");
  container.innerHTML = ELECTION_POSITIONS.map(pos => {
    const posTotal = pos.candidates.reduce((sum, c) => sum + (votes[c.id] || 0), 0);
    const maxVote = Math.max(...pos.candidates.map(c => votes[c.id] || 0));
    const sorted = [...pos.candidates].sort((a, b) => (votes[b.id] || 0) - (votes[a.id] || 0));

    return `
      <div class="position-box">
        <div class="position-box-header">
          <h3>${pos.title}</h3>
          <span>${posTotal} certified votes</span>
        </div>
        ${sorted
          .map(cand => {
            const count = votes[cand.id] || 0;
            const pct = posTotal > 0 ? ((count / posTotal) * 100).toFixed(1) : "0.0";
            const isLeader = count === maxVote && count > 0;

            return `
              <div class="result-item">
                <div class="result-meta">
                  <span>
                    <strong>${cand.name}</strong>
                    <span style="color: var(--text-muted); font-size: 0.82rem;">(${cand.party})</span>
                    ${isLeader ? '<span class="leader-tag">LEADING</span>' : ""}
                  </span>
                  <span><strong>${count}</strong> votes (${pct}%)</span>
                </div>
                <div class="bar-track">
                  <div class="bar-fill ${isLeader ? "leader" : ""}" style="width: ${pct}%"></div>
                </div>
              </div>
            `;
          })
          .join("")}
      </div>
    `;
  }).join("");
}

// 15. Student Profile View
function renderProfileView() {
  const container = document.getElementById("profile-container");
  const editableFields = [
    { key: "contactNumber", label: "Contact Number", type: "tel" },
    { key: "emergencyNumber", label: "Emergency Number", type: "tel" },
    { key: "birthdate", label: "Birthdate", type: "date" },
    { key: "address", label: "Address", type: "text" }
  ];

  container.innerHTML = `
    <div style="display: flex; align-items: center; gap: 16px; padding-bottom: 16px; border-bottom: 1px solid var(--purple-border);">
      <div class="cand-avatar-md" style="width: 64px; height: 64px; font-size: 1.4rem;">
        ${activeStudent.name.slice(0, 2).toUpperCase()}
      </div>
      <div>
        <h3 style="font-size: 1.25rem; color: var(--sidebar-deep);">${activeStudent.name}</h3>
        <span class="party-pill" style="margin: 4px 0 0;">Verified Student Voter • ${activeStudent.studentId}</span>
      </div>
    </div>
    <div class="profile-grid">
      <div class="profile-field">
        <span>Student ID</span>
        <strong>${activeStudent.studentId}</strong>
      </div>
      <div class="profile-field">
        <span>Department / College</span>
        <strong>${activeStudent.department || "CICS"}</strong>
      </div>
      <div class="profile-field">
        <span>Course &amp; Section</span>
        <strong>${activeStudent.course || "BSIT"} • ${activeStudent.yearSection || "3A"}</strong>
      </div>
      ${editableFields
        .map(
          f => `
          <div class="profile-field editable-field" data-prof-edit="${f.key}">
            <span>
              ${f.label}
              <em class="edit-badge"><i class="fa-solid fa-pen"></i> Edit</em>
            </span>
            <strong id="prof-val-${f.key}">${activeStudent[f.key] || "Not provided"}</strong>
            <div class="inline-edit-box hidden" id="prof-editor-${f.key}">
              <input type="${f.type}" class="inline-edit-input" id="prof-input-${f.key}" value="${activeStudent[f.key] || ""}" />
              <div class="inline-edit-actions">
                <button type="button" class="btn-mini-save" data-prof-save="${f.key}">Save</button>
                <button type="button" class="btn-mini-cancel" data-prof-cancel="${f.key}">Cancel</button>
              </div>
            </div>
          </div>
        `
        )
        .join("")}
    </div>
  `;

  container.querySelectorAll("[data-prof-edit]").forEach(card => {
    card.addEventListener("click", e => {
      if (e.target.closest(".inline-edit-box")) return;
      const key = card.dataset.profEdit;
      document.getElementById(`prof-val-${key}`).classList.add("hidden");
      document.getElementById(`prof-editor-${key}`).classList.remove("hidden");
      document.getElementById(`prof-input-${key}`).focus();
    });
  });

  container.querySelectorAll("[data-prof-save]").forEach(btn => {
    btn.addEventListener("click", e => {
      e.stopPropagation();
      const key = btn.dataset.profSave;
      const newVal = document.getElementById(`prof-input-${key}`).value.trim();
      if (!newVal) {
        showToast("Field cannot be empty.");
        return;
      }
      activeStudent[key] = newVal;
      persistStudentUpdates().catch(error => showToast(error.message || "Profile update failed."));
      renderProfileView();
      showToast("Profile updated!");
    });
  });

  container.querySelectorAll("[data-prof-cancel]").forEach(btn => {
    btn.addEventListener("click", e => {
      e.stopPropagation();
      const key = btn.dataset.profCancel;
      document.getElementById(`prof-editor-${key}`).classList.add("hidden");
      document.getElementById(`prof-val-${key}`).classList.remove("hidden");
    });
  });
}

// 16. Toast Helper
let toastTimer;
function showToast(msg) {
  const box = document.getElementById("toast-box");
  document.getElementById("toast-message").textContent = msg;
  box.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => box.classList.remove("show"), 2800);
}

// INITIALIZE APPLICATION
document.addEventListener("DOMContentLoaded", () => {
  onAuthStateChanged(auth, async user => {
    if (!user) { window.location.replace(LOGIN_PAGE_PATH); return; }
    try {
      await loadCurrentStudent();
      initElectionData();
      renderUserIdentity();
      startCountdown();
      setupNavigation();
      renderDashboardWidgets();
      renderAllCandidates();
      setupModal();
    } catch (error) {
      console.error(error);
      alert("Your student account could not be verified. Please sign in again.");
      window.location.replace(LOGIN_PAGE_PATH);
    }
  });
});
