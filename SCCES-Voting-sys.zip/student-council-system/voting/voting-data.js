const ELECTION_POSITIONS = [
  {
    id: "president",
    title: "President",
    subtitle: "Chief Executive Officer of the Student Council",
    candidates: [
      {
        id: "pres-daniel",
        name: "Daniel Reyes",
        initials: "DR",
        grade: "4th Year • BS Computer Science",
        party: "Unity Party",
        featured: true,
        slogan: "Transparent governance, stronger student welfare, and unified campus action.",
        bio: "Former CICS Student Council Governor and Chairperson of the Student Welfare Committee.",
        platform: [
          "Publish a real-time monthly Student Council financial transparency ledger.",
          "Extend campus library and co-working study hub hours until 8:00 PM.",
          "Establish an emergency student book & internet connectivity grant."
        ],
        initialVotes: 46
      },
      {
        id: "pres-claire",
        name: "Claire Mendoza",
        initials: "CM",
        grade: "4th Year • BS Business Administration",
        party: "Progress Party",
        featured: false,
        slogan: "Modernizing student services and bridging every college.",
        bio: "Two-term Student Senator and Coordinator of the University Leadership Summit.",
        platform: [
          "Launch a unified campus mobile helpdesk for academic and scholarship inquiries.",
          "Expand inter-college sports, arts, and innovation competitions.",
          "Partner with local businesses for student internship and discount cards."
        ],
        initialVotes: 34
      }
    ]
  },
  {
    id: "vice-president",
    title: "Vice President",
    subtitle: "Head of Internal Affairs & Accredited Student Organizations",
    candidates: [
      {
        id: "vp-maria",
        name: "Maria Santos",
        initials: "MS",
        grade: "3rd Year • BS Information Technology",
        party: "Progress Party",
        featured: true,
        slogan: "Empowering every student organization to thrive without red tape.",
        bio: "President of the Tech Innovators Guild and Lead Organizer of Campus HackFest.",
        platform: [
          "Reduce student organization event approval processing time to 48 hours.",
          "Create a shared equipment and sound-system lending pool for all clubs.",
          "Host quarterly General Assemblies with open student Q&A forums."
        ],
        initialVotes: 48
      },
      {
        id: "vp-ethan",
        name: "Ethan Villanueva",
        initials: "EV",
        grade: "3rd Year • BS Civil Engineering",
        party: "Unity Party",
        featured: false,
        slogan: "Reliable support for student clubs, facilities, and campus life.",
        bio: "Engineering Society Vice President and Campus Sustainability Advocate.",
        platform: [
          "Upgrade student lounge seating, charging stations, and water refill points.",
          "Guarantee baseline seed funding for newly accredited student organizations.",
          "Coordinate semester-wide peer tutoring hubs across all colleges."
        ],
        initialVotes: 32
      }
    ]
  },
  {
    id: "secretary",
    title: "Secretary",
    subtitle: "Official Custodian of Council Records & Student Communications",
    candidates: [
      {
        id: "sec-james",
        name: "James Cortez",
        initials: "JC",
        grade: "3rd Year • BA English",
        party: "Future Party",
        featured: true,
        slogan: "Clear records, open minutes, and zero communication gaps.",
        bio: "Associate Editor of the Campus Chronicle and Student Senate Minutes Officer.",
        platform: [
          "Upload searchable council session minutes and resolutions within 24 hours.",
          "Send a concise weekly Monday Campus Digest to all student portals.",
          "Maintain a centralized university calendar of academic and org deadlines."
        ],
        initialVotes: 44
      },
      {
        id: "sec-hannah",
        name: "Hannah Bautista",
        initials: "HB",
        grade: "2nd Year • BS Secondary Education",
        party: "Victory Party",
        featured: false,
        slogan: "Keeping every student informed, heard, and connected.",
        bio: "Sophomore Class Representative and Campus Radio Host.",
        platform: [
          "Install QR feedback boards in every college building.",
          "Publish visual bi-weekly progress trackers on council projects.",
          "Stream open council deliberations for off-campus students."
        ],
        initialVotes: 36
      }
    ]
  },
  {
    id: "treasurer",
    title: "Treasurer",
    subtitle: "Chief Financial Officer & Student Fund Auditor",
    candidates: [
      {
        id: "tres-sophia",
        name: "Sophia Lopez",
        initials: "SL",
        grade: "3rd Year • BS Accountancy",
        party: "Victory Party",
        featured: true,
        slogan: "Every peso accounted for, every project delivered with integrity.",
        bio: "Junior Philippine Institute of Accountants Officer and Audit Committee Lead.",
        platform: [
          "Publish itemized receipts and audit summaries after every council event.",
          "Reallocate unused administrative funds directly to student org grants.",
          "Host free financial literacy workshops for student organization treasurers."
        ],
        initialVotes: 51
      },
      {
        id: "tres-noah",
        name: "Noah Cruz",
        initials: "NC",
        grade: "3rd Year • BA Economics",
        party: "Future Party",
        featured: false,
        slogan: "Smart budgeting for high-impact student initiatives.",
        bio: "Economics Society Treasurer and University Debate Union Finance Head.",
        platform: [
          "Implement digital disbursement tracking for faster club reimbursements.",
          "Establish a transparent participatory budget poll for student projects.",
          "Negotiate bulk vendor discounts for campus-wide student events."
        ],
        initialVotes: 29
      }
    ]
  }
];
