# SCCES Firebase Spark migration

## Included in this migration
- Firebase Authentication for student registration and login.
- Student profile records in Cloud Firestore (no passwords are stored in Firestore or localStorage).
- Admin portal access based on a manually provisioned `admins/{uid}` document.
- Firestore-backed admin CRUD for student records, candidates, positions, election schedules, and security rules.
- Firestore Security Rules that prevent students from accessing admin-managed collections and prevent browser-created admin roles.
- Voting portal now requires a signed-in Firebase student profile; it no longer falls back to the hard-coded demo student.

## 1. Confirm Firebase setup
In Firebase Console for project `student-council-election-sys`:
1. Authentication → Sign-in method → enable **Email/Password**.
2. Firestore Database → create the database.
3. Authentication → Settings → Authorized domains: add the domain where you host the project (localhost is normally already available).

## 2. Publish Firestore Rules
1. Open Firestore Database → Rules.
2. Replace the editor contents with `firestore.rules` from this folder.
3. Click **Publish**.

Do not leave Firestore in test mode. The supplied rules are the access-control layer for this app.

## 3. Create the administrator account safely
1. In Firebase Console → Authentication → Users → Add user, create the administrator's email/password account. Do not put the password in HTML or JavaScript.
2. Open that user and copy the Firebase **UID**.
3. In Firestore → Data, create a collection named `admins`.
4. Create a document whose **document ID is exactly the administrator UID**.
5. Add fields such as:
   - `name` (string): Administrator display name
   - `email` (string): administrator email
   - `role` (string): `admin`

Only create this document through the Firebase Console or a trusted server. The Firestore Rules deny client-side writes to `admins`, so students cannot promote themselves.

## 4. Run the project
Serve the extracted project from a local web server or your normal hosting provider. Do not open the HTML files directly with `file://`, because Firebase ES module imports need an HTTP(S) origin. The root `firebase.js` file must remain alongside the `login`, `admin`, and `voting` folders.

## 5. Test in this order
1. Sign in with the administrator account and confirm it opens `admin/admin.html`.
2. Try opening `admin/admin.html` in a signed-out browser; it should redirect to login.
3. Register a test student with a unique Student ID and email.
4. Sign in as that student; it should open `voting/voting.html`.
5. Confirm the student cannot open the admin portal.
6. In the admin portal, test add/edit/delete for candidates, positions, election schedules, security rules, and student profile records.

## Important limitations of the Spark migration
- **Official vote submission is intentionally disabled.** The existing voting code used browser localStorage for votes and tallies, which users can edit. A secure official election requires trusted server-side validation and tallying. Cloud Functions is one route, but it requires Blaze; another trusted backend can also be considered.
- The existing candidate and position display on the student voting page is still the static sample data in `voting/voting-data.js`. The admin Firestore CRUD is saved in Firestore but is not yet synchronized into that student display.
- Student registration creates Firebase Authentication accounts. The admin student CRUD manages Firestore student profile records; it does not create or delete Firebase Authentication accounts. To disable/delete an account, use Firebase Console → Authentication.
- Sample records in the old `admin-data.js` and `voting-data.js` are demo content. They are not migrated as real registered students or certified election results.
- Admin UID provisioning is manual. Never add a password or an admin-creation button to client-side code.

## Data collections
- `admins/{uid}` — administrator allowlist; provision manually in Firebase Console.
- `students/{uid}` — student profile, keyed by Firebase Authentication UID.
- `studentIds/{lowercaseStudentId}` — unique Student ID reservation.
- `candidates/{documentId}` — candidate records managed by admins.
- `positions/{documentId}` — position records managed by admins.
- `elections/{documentId}` — election schedules managed by admins.
- `securityRules/{documentId}` — displayed election/security rule records managed by admins.
- `ballots` and `tallies` — client writes are denied until a trusted voting backend is implemented.
