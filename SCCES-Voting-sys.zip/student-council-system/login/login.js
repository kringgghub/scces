import { auth, db } from '../firebase.js';
import {
  createUserWithEmailAndPassword, signInWithEmailAndPassword,
  updateProfile, signOut
} from 'https://www.gstatic.com/firebasejs/13.4.0/firebase-auth.js';
import {
  doc, writeBatch, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/13.4.0/firebase-firestore.js';

const coursesByDepartment = {
  CICS:[['BSIT','Bachelor of Science in Information Technology (BSIT)'],['BSCS','Bachelor of Science in Computer Science (BSCS)'],['BLIS','Bachelor of Library and Information Science (BLIS)']],
  COE:[['BEES','Bachelor of Elementary Education (BEES)'],['BSED','Bachelor of Secondary Education (BSED)'],['BPED','Bachelor of Physical Education (BPED)']],
  COENG:[['BSCE','Bachelor of Science in Civil Engineering (BSCE)'],['BSME','Bachelor of Science in Mechanical Engineering (BSME)']],
  COM:[['BSPA','Bachelor of Public Administration (BSPA)'],['BSBA','Bachelor of Science in Business Administration (BSBA)'],['BS ENTERP','Bachelor of Science in Entrepreneurship (BS ENTERP)']],
  CAS:[['BS English','Bachelor of Arts in English (BS English)'],['BS Economics','Bachelor of Arts in Economics (BS Economics)'],['BS Biology','Bachelor of Science in Biology (BS Biology)']],
  CIT:[['Electrical Technology','Bachelor of Electrical Technology'],['Automotive','Bachelor of Automotive Technology'],['Drafting Technology','Bachelor of Drafting Technology']],
  CHTM:[['BSHTM','Bachelor of Science in Hospitality and Tourism Management (BSHTM)']]
};
const byId = id => document.getElementById(id);
const registerDepartment = byId('registerDepartment');
const registerCourse = byId('registerCourse');

registerDepartment?.addEventListener('change', () => {
  registerCourse.replaceChildren(new Option('Select course / program',''));
  const list = coursesByDepartment[registerDepartment.value];
  if (!list) { registerCourse.disabled = true; return; }
  list.forEach(([value,label]) => registerCourse.add(new Option(label,value)));
  registerCourse.disabled = false;
});

const PASSWORD_RULES = [
  ['length', p => p.length >= 8], ['lowercase', p => /[a-z]/.test(p)],
  ['uppercase', p => /[A-Z]/.test(p)], ['number', p => /\d/.test(p)],
  ['special', p => /[^A-Za-z0-9\s]/.test(p)]
];
function passwordResults(password) { return PASSWORD_RULES.map(([id,test]) => ({id,met:test(password)})); }
function updatePasswordRequirements() {
  const password = byId('registerPassword')?.value || '';
  passwordResults(password).forEach(({id,met}) => {
    const item = document.querySelector(`[data-password-rule="${id}"]`);
    if (!item) return;
    item.classList.toggle('text-emerald-300',met);
    item.classList.toggle('text-purple-300/80',!met);
    item.querySelector('i')?.classList.toggle('fa-check',met);
    item.querySelector('i')?.classList.toggle('fa-xmark',!met);
    const status = item.querySelector('[data-password-rule-status]');
    if (status) status.textContent = met ? 'Met' : 'Not met';
  });
}
function updatePasswordMatchWarning() {
  const p = byId('registerPassword')?.value || '';
  const c = byId('confirmPassword')?.value || '';
  byId('passwordMismatchWarning')?.classList.toggle('hidden', !(p && c) || p === c);
  byId('passwordMatchSuccess')?.classList.toggle('hidden', !(p && c) || p !== c);
}
function sanitizePhone(input) { input.value = input.value.replace(/\D/g,'').slice(0,11); }
let toastTimeout;
function showToast(message) {
  const toast = byId('toast'); const msg = byId('toast-msg');
  if (!toast || !msg) { alert(message); return; }
  msg.textContent = message;
  toast.classList.remove('translate-y-20','opacity-0');
  toast.classList.add('translate-y-0','opacity-100');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    toast.classList.remove('translate-y-0','opacity-100');
    toast.classList.add('translate-y-20','opacity-0');
  },3000);
}
window.showToast = showToast;
window.togglePasswordVisibility = (inputId,button) => {
  const input = byId(inputId); if (!input) return;
  const visible = input.type === 'text'; input.type = visible ? 'password' : 'text';
  button.querySelector('i')?.classList.toggle('fa-eye',!visible);
  button.querySelector('i')?.classList.toggle('fa-eye-slash',visible);
  button.setAttribute('aria-pressed',String(!visible));
};
window.switchAuthMode = mode => {
  const isLogin = mode === 'login';
  byId('loginForm')?.classList.toggle('hidden',!isLogin);
  byId('registerForm')?.classList.toggle('hidden',isLogin);
  byId('studentLoginTab')?.classList.toggle('bg-purple-700',isLogin);
  byId('studentLoginTab')?.classList.toggle('text-white',isLogin);
  byId('studentLoginTab')?.classList.toggle('text-purple-200',!isLogin);
  byId('studentRegisterTab')?.classList.toggle('bg-purple-700',!isLogin);
  byId('studentRegisterTab')?.classList.toggle('text-white',!isLogin);
  byId('studentRegisterTab')?.classList.toggle('text-purple-200',isLogin);
};

async function handleStudentRegistration(event) {
  event.preventDefault();
  const value = id => byId(id)?.value?.trim() || '';
  const name=value('registerName'), gender=value('registerGender'), studentId=value('registerStudentId');
  const department=value('registerDepartment'), course=value('registerCourse'), yearSection=value('registerYearSection');
  const contactNumber=value('registerContactNumber'), emergencyNumber=value('registerEmergencyNumber');
  const birthDate=value('registerBirthDate'), address=value('registerAddress'), email=value('registerEmail').toLowerCase();
  const password=byId('registerPassword').value, confirmPassword=byId('confirmPassword').value;
  if (![name,gender,studentId,department,course,yearSection,contactNumber,emergencyNumber,birthDate,address,email,password,confirmPassword].every(Boolean)) return showToast('Please complete all fields.');
  if (!/^09\d{9}$/.test(contactNumber) || !/^09\d{9}$/.test(emergencyNumber)) return showToast('Phone numbers must contain exactly 11 digits and start with 09.');
  if (password !== confirmPassword) return showToast('Passwords do not match.');
  if (!passwordResults(password).every(x=>x.met)) return showToast('Password must meet all 5 security requirements.');
  if (studentId.includes('/')) return showToast('Student ID cannot contain a slash.');

  let credential;
  try {
    credential = await createUserWithEmailAndPassword(auth,email,password);
    await updateProfile(credential.user,{displayName:name});
    const normalizedId = studentId.toLowerCase();
    const batch = writeBatch(db);
    batch.set(doc(db,'students',credential.user.uid), {
      uid:credential.user.uid, name, gender, studentId, studentIdKey:normalizedId,
      department, departmentName:registerDepartment.options[registerDepartment.selectedIndex].textContent,
      course, yearSection, contactNumber, emergencyNumber, birthDate, address,
      email, role:'student', createdAt:serverTimestamp(), updatedAt:serverTimestamp()
    });
    batch.set(doc(db,'studentIds',normalizedId),{uid:credential.user.uid,studentId,createdAt:serverTimestamp()});
    await batch.commit();
    await signOut(auth);
    byId('registerForm').reset();
    registerCourse.replaceChildren(new Option('Select a department / college first',''));
    registerCourse.disabled = true;
    updatePasswordRequirements(); updatePasswordMatchWarning();
    window.switchAuthMode('login');
    showToast('Account created! You can now log in.');
  } catch (error) {
    if (credential?.user) { try { await credential.user.delete(); } catch (_) {} }
    const messages = {
      'auth/email-already-in-use':'This email is already registered.',
      'auth/invalid-email':'Please enter a valid email address.',
      'auth/weak-password':'Choose a stronger password.',
      'permission-denied':'This Student ID may already be registered, or Firestore Rules are not published.'
    };
    showToast(messages[error.code] || error.message || 'Registration failed.');
  }
}
async function handleStudentLogin(event) {
  event.preventDefault();
  const email=byId('loginEmail').value.trim().toLowerCase();
  const password=byId('loginPassword').value;
  if (!email || !password) return showToast('Enter your student email and password.');
  try {
    const credential = await signInWithEmailAndPassword(auth,email,password);
    const { getDoc, doc } = await import('https://www.gstatic.com/firebasejs/13.4.0/firebase-firestore.js');
    const adminSnap = await getDoc(doc(db,'admins',credential.user.uid));
    if (adminSnap.exists()) {
      showToast('Administrator authenticated. Redirecting...');
      setTimeout(()=>window.location.replace('../admin/admin.html'),450);
      return;
    }
    const studentSnap = await getDoc(doc(db,'students',credential.user.uid));
    if (!studentSnap.exists() || studentSnap.data().role !== 'student') {
      await signOut(auth);
      return showToast('Your student profile is not authorized. Contact the election administrator.');
    }
    showToast('Login successful. Redirecting to voting...');
    setTimeout(()=>window.location.replace('../voting/voting.html'),450);
  } catch (error) {
    const messages={'auth/invalid-credential':'Invalid email or password.','auth/user-not-found':'Account not found.','auth/wrong-password':'Invalid email or password.','auth/too-many-requests':'Too many attempts. Please try again later.'};
    showToast(messages[error.code] || error.message || 'Login failed.');
  }
}

byId('loginForm')?.addEventListener('submit',handleStudentLogin);
const registerForm=byId('registerForm');
registerForm?.addEventListener('submit',handleStudentRegistration);
registerForm?.addEventListener('reset',()=>{
  registerCourse?.replaceChildren(new Option('Select a department / college first',''));
  if(registerCourse) registerCourse.disabled=true;
});
['registerContactNumber','registerEmergencyNumber'].forEach(id=>byId(id)?.addEventListener('input',e=>sanitizePhone(e.currentTarget)));
byId('registerPassword')?.addEventListener('input',()=>{updatePasswordRequirements();updatePasswordMatchWarning();});
byId('confirmPassword')?.addEventListener('input',updatePasswordMatchWarning);
updatePasswordRequirements(); window.switchAuthMode('login');
