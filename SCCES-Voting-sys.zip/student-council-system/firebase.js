// Firebase client configuration for SCCES.
// The web API key identifies the Firebase project; Firestore Rules enforce access.
import { initializeApp } from 'https://www.gstatic.com/firebasejs/13.4.0/firebase-app.js';
import { getAuth } from 'https://www.gstatic.com/firebasejs/13.4.0/firebase-auth.js';
import { getFirestore } from 'https://www.gstatic.com/firebasejs/13.4.0/firebase-firestore.js';

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCEjAgMlbrbk4YJsxkvd0ujv1ctsd_RRXk",
  authDomain: "student-council-election-sys.firebaseapp.com",
  projectId: "student-council-election-sys",
  storageBucket: "student-council-election-sys.firebasestorage.app",
  messagingSenderId: "899242107712",
  appId: "1:899242107712:web:dae986339bbbdb354e50a5",
  measurementId: "G-PTBV4XJ64B"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
