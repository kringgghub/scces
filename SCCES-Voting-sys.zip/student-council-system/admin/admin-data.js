const ADMIN_STORAGE = {
  STUDENTS: "scces_admin_students_2026",
  CANDIDATES: "scces_admin_candidates_2026",
  POSITIONS: "scces_admin_positions_2026",
  ELECTIONS: "scces_admin_elections_2026",
  VOTES: "scces_votes_2026",
  VOTED_IDS: "scces_voted_ids_2026",
  RECEIPTS: "scces_receipts_2026",
  TOTAL_BALLOTS: "scces_total_ballots_2026",
  POLL_STATUS: "scces_election_status_2026",
  SECURITY_RULES: "scces_security_rules_2026",
  ADMIN_PROFILE: "scces_admin_profile_2026"
};

const DEFAULT_ADMIN_PROFILE = {
  name: "Admin Director",
  adminId: "ADM-2026-001",
  role: "Election Commission Chairperson",
  department: "Office of Student Affairs (OSA)",
  email: "admin.director@school.edu",
  contactNumber: "0917-888-2026",
  emergencyNumber: "0918-888-2026",
  birthdate: "1995-04-12",
  address: "Student Center Room 201, Main Campus"
};

const DEFAULT_STUDENTS = [
  { id: "2026-1042", name: "Sophia Lopez", department: "CICS", course: "BSIT", yearSection: "3A", email: "sophia.lopez@school.edu", contactNumber: "0917-555-0192", status: "Pending" },
  { id: "2026-1043", name: "Daniel Reyes", department: "CICS", course: "BSCS", yearSection: "4A", email: "daniel.reyes@school.edu", contactNumber: "0917-555-0193", status: "Voted" },
  { id: "2026-1044", name: "Maria Santos", department: "CICS", course: "BSIT", yearSection: "3B", email: "maria.santos@school.edu", contactNumber: "0917-555-0194", status: "Voted" },
  { id: "2026-1045", name: "James Cortez", department: "CAS", course: "BA English", yearSection: "3A", email: "james.cortez@school.edu", contactNumber: "0917-555-0195", status: "Pending" },
  { id: "2026-1046", name: "Hannah Bautista", department: "COE", course: "BSED", yearSection: "2A", email: "hannah.bautista@school.edu", contactNumber: "0917-555-0196", status: "Voted" },
  { id: "2026-1047", name: "Claire Mendoza", department: "COM", course: "BSBA", yearSection: "4A", email: "claire.mendoza@school.edu", contactNumber: "0917-555-0197", status: "Pending" },
  { id: "2026-1048", name: "Ethan Villanueva", department: "COENG", course: "BSCE", yearSection: "3A", email: "ethan.villanueva@school.edu", contactNumber: "0917-555-0198", status: "Voted" },
  { id: "2026-1049", name: "Noah Cruz", department: "CAS", course: "BA Economics", yearSection: "3B", email: "noah.cruz@school.edu", contactNumber: "0917-555-0199", status: "Voted" }
];

const DEFAULT_POSITIONS = [
  { id: "president", title: "President", subtitle: "Chief Executive Officer of the Student Council" },
  { id: "vice-president", title: "Vice President", subtitle: "Head of Internal Affairs & Accredited Student Organizations" },
  { id: "secretary", title: "Secretary", subtitle: "Official Custodian of Council Records & Student Communications" },
  { id: "treasurer", title: "Treasurer", subtitle: "Chief Financial Officer & Student Fund Auditor" }
];

const DEFAULT_CANDIDATES = [
  {
    id: "pres-daniel",
    positionId: "president",
    name: "Daniel Reyes",
    initials: "DR",
    grade: "4th Year • BS Computer Science",
    party: "Unity Party",
    featured: true,
    slogan: "Transparent governance, stronger student welfare, and unified campus action.",
    bio: "Former CICS Student Council Governor and Chairperson of the Student Welfare Committee.",
    platform: [
      "Publish a real-time monthly Student Council financial transparency ledger.",
      "Extend campus library and co-working study hub hours until 8:00 PM.",
      "Establish an emergency student book & internet connectivity grant."
    ],
    initialVotes: 46
  },
  {
    id: "pres-claire",
    positionId: "president",
    name: "Claire Mendoza",
    initials: "CM",
    grade: "4th Year • BS Business Administration",
    party: "Progress Party",
    featured: false,
    slogan: "Modernizing student services and bridging every college.",
    bio: "Two-term Student Senator and Coordinator of the University Leadership Summit.",
    platform: [
      "Launch a unified campus mobile helpdesk for academic and scholarship inquiries.",
      "Expand inter-college sports, arts, and innovation competitions.",
      "Partner with local businesses for student internship and discount cards."
    ],
    initialVotes: 34
  },
  {
    id: "vp-maria",
    positionId: "vice-president",
    name: "Maria Santos",
    initials: "MS",
    grade: "3rd Year • BS Information Technology",
    party: "Progress Party",
    featured: true,
    slogan: "Empowering every student organization to thrive without red tape.",
    bio: "President of the Tech Innovators Guild and Lead Organizer of Campus HackFest.",
    platform: [
      "Reduce student organization event approval processing time to 48 hours.",
      "Create a shared equipment and sound-system lending pool for all clubs.",
      "Host quarterly General Assemblies with open student Q&A forums."
    ],
    initialVotes: 48
  },
  {
    id: "vp-ethan",
    positionId: "vice-president",
    name: "Ethan Villanueva",
    initials: "EV",
    grade: "3rd Year • BS Civil Engineering",
    party: "Unity Party",
    featured: false,
    slogan: "Reliable support for student clubs, facilities, and campus life.",
    bio: "Engineering Society Vice President and Campus Sustainability Advocate.",
    platform: [
      "Upgrade student lounge seating, charging stations, and water refill points.",
      "Guarantee baseline seed funding for newly accredited student organizations.",
      "Coordinate semester-wide peer tutoring hubs across all colleges."
    ],
    initialVotes: 32
  },
  {
    id: "sec-james",
    positionId: "secretary",
    name: "James Cortez",
    initials: "JC",
    grade: "3rd Year • BA English",
    party: "Future Party",
    featured: true,
    slogan: "Clear records, open minutes, and zero communication gaps.",
    bio: "Associate Editor of the Campus Chronicle and Student Senate Minutes Officer.",
    platform: [
      "Upload searchable council session minutes and resolutions within 24 hours.",
      "Send a concise weekly Monday Campus Digest to all student portals.",
      "Maintain a centralized university calendar of academic and org deadlines."
    ],
    initialVotes: 44
  },
  {
    id: "sec-hannah",
    positionId: "secretary",
    name: "Hannah Bautista",
    initials: "HB",
    grade: "2nd Year • BS Secondary Education",
    party: "Victory Party",
    featured: false,
    slogan: "Keeping every student informed, heard, and connected.",
    bio: "Sophomore Class Representative and Campus Radio Host.",
    platform: [
      "Install QR feedback boards in every college building.",
      "Publish visual bi-weekly progress trackers on council projects.",
      "Stream open council deliberations for off-campus students."
    ],
    initialVotes: 36
  },
  {
    id: "tres-sophia",
    positionId: "treasurer",
    name: "Sophia Lopez",
    initials: "SL",
    grade: "3rd Year • BS Accountancy",
    party: "Victory Party",
    featured: true,
    slogan: "Every peso accounted for, every project delivered with integrity.",
    bio: "Junior Philippine Institute of Accountants Officer and Audit Committee Lead.",
    platform: [
      "Publish itemized receipts and audit summaries after every council event.",
      "Reallocate unused administrative funds directly to student org grants.",
      "Host free financial literacy workshops for student organization treasurers."
    ],
    initialVotes: 51
  },
  {
    id: "tres-noah",
    positionId: "treasurer",
    name: "Noah Cruz",
    initials: "NC",
    grade: "3rd Year • BA Economics",
    party: "Future Party",
    featured: false,
    slogan: "Smart budgeting for high-impact student initiatives.",
    bio: "Economics Society Treasurer and University Debate Union Finance Head.",
    platform: [
      "Implement digital disbursement tracking for faster club reimbursements.",
      "Establish a transparent participatory budget poll for student projects.",
      "Negotiate bulk vendor discounts for campus-wide student events."
    ],
    initialVotes: 29
  }
];

const DEFAULT_ELECTIONS = [
  {
    id: "el-2026",
    title: "Student Council Election 2026",
    startDate: "2026-11-15",
    endDate: "2026-11-30",
    endTime: "23:59",
    status: "Ongoing"
  }
];

const DEFAULT_SECURITY_RULES = [
  {
    id: "rule-1",
    icon: "fa-user-lock",
    title: "1 ID = 1 Vote Strict Enforcement",
    description: "Each verified Student ID is permitted exactly one official ballot submission. Once submitted, the ballot locks permanently to prevent duplicate voting."
  },
  {
    id: "rule-2",
    icon: "fa-calendar-check",
    title: "Official Election Period & Deadline",
    description: "Election Opens: November 15, 2026 at 8:00 AM • Election Ends: November 30, 2026 at 11:59 PM (Polls automatically lock at deadline)."
  },
  {
    id: "rule-3",
    icon: "fa-receipt",
    title: "Verifiable Digital Receipt & Ballot Secrecy",
    description: "Every submitted ballot generates a unique SCCES-XXXXXX confirmation code while separating voter identity from public tally counters."
  },
  {
    id: "rule-4",
    icon: "fa-database",
    title: "Tamper-Resistant Tally Auditing",
    description: "All vote increments are validated per office before updating live certified election results."
  }
];
