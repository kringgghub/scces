import { auth, db } from '../firebase.js';

import {
  onAuthStateChanged,
  signOut
} from 'https://www.gstatic.com/firebasejs/13.4.0/firebase-auth.js';

import {
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  serverTimestamp
} from 'https://www.gstatic.com/firebasejs/13.4.0/firebase-firestore.js';

const LOGIN_PATH = '../login/login.html';

const $ = id => document.getElementById(id);

const escapeHtml = value =>
  String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[char]);

let adminProfile = null;

function toast(message) {
  const box = $('toast-box');
  const messageBox = $('toast-message');

  if (!box || !messageBox) {
    alert(message);
    return;
  }

  messageBox.textContent = message;
  box.classList.add('show');

  setTimeout(() => {
    box.classList.remove('show');
  }, 2600);
}

function collectionConfig() {
  return [
    {
      key: 'students',
      title: 'Student Records',
      container: 'students-table-body',
      fields: [
        ['name', 'Full name'],
        ['studentId', 'Student ID'],
        ['email', 'Email'],
        ['department', 'Department'],
        ['course', 'Course'],
        ['yearSection', 'Year / Section'],
        ['contactNumber', 'Contact number']
      ]
    },
    {
      key: 'candidates',
      title: 'Candidates',
      container: 'all-candidates-container',
      fields: [
        ['name', 'Candidate name'],
        ['positionId', 'Position ID'],
        ['party', 'Party'],
        ['grade', 'Year / course'],
        ['slogan', 'Slogan'],
        ['bio', 'Biography']
      ]
    },
    {
      key: 'positions',
      title: 'Positions',
      container: 'positions-table-body',
      fields: [
        ['title', 'Position title'],
        ['subtitle', 'Description']
      ]
    },
    {
      key: 'elections',
      title: 'Election Schedules',
      container: 'elections-grid-container',
      fields: [
        ['title', 'Election title'],
        ['startDate', 'Start date (YYYY-MM-DD)'],
        ['endDate', 'End date (YYYY-MM-DD)'],
        ['status', 'Status']
      ]
    },
    {
      key: 'securityRules',
      title: 'Security Rules',
      container: 'admin-security-rules-list',
      fields: [
        ['title', 'Rule title'],
        ['description', 'Description']
      ]
    }
  ];
}

function askFields(config, record = {}) {
  const result = {};

  for (const [field, label] of config.fields) {
    const value = prompt(`${label}:`, record[field] ?? '');

    if (value === null) {
      return null;
    }

    if (!value.trim()) {
      alert(`${label} is required.`);
      return null;
    }

    result[field] = value.trim();
  }

  return result;
}

async function loadCollection(config) {
  const snapshot = await getDocs(collection(db, config.key));

  return snapshot.docs.map(document => ({
    id: document.id,
    ...document.data()
  }));
}

function targetContainer(config) {
  const target = $(config.container);

  if (!target) {
    return null;
  }

  if (
    config.container === 'students-table-body' ||
    config.container === 'positions-table-body'
  ) {
    const table = target.closest('table');

    if (table) {
      const parent = table.parentElement;

      let panel = parent.querySelector(
        `[data-firestore-panel="${config.key}"]`
      );

      if (!panel) {
        panel = document.createElement('div');
        panel.dataset.firestorePanel = config.key;
        panel.className = 'panel-card';

        parent.appendChild(panel);
      }

      return panel;
    }
  }

  return target;
}

async function renderCollection(config) {
  const target = targetContainer(config);

  if (!target) {
    console.warn(`Container not found: ${config.container}`);
    return;
  }

  const records = await loadCollection(config);

  const rows = records.map(record => {
    const details = config.fields
      .map(([field]) =>
        `${escapeHtml(field)}: ${escapeHtml(record[field] || '—')}`
      )
      .join(' · ');

    const displayName =
      record.name ||
      record.title ||
      record.studentId ||
      'Record';

    return `
      <div class="panel-card"
        style="margin:10px 0;padding:14px;display:flex;gap:12px;
        align-items:center;justify-content:space-between;flex-wrap:wrap">

        <div style="min-width:180px;flex:1">
          <strong>${escapeHtml(displayName)}</strong>
          <div style="font-size:12px;opacity:.75">
            ${details}
          </div>
        </div>

        <div style="display:flex;gap:8px">
          <button
            type="button"
            data-edit="${escapeHtml(record.id)}"
            class="btn-pill-outline">
            Edit
          </button>

          <button
            type="button"
            data-delete="${escapeHtml(record.id)}"
            class="btn-outline-danger">
            Delete
          </button>
        </div>
      </div>
    `;
  }).join('');

  target.innerHTML = `
    <div style="display:flex;justify-content:space-between;
      align-items:center;gap:12px;flex-wrap:wrap;margin:14px 0">

      <h3>${escapeHtml(config.title)} (Firestore)</h3>

      <button type="button" class="btn-purple-solid" data-add>
        + Add ${escapeHtml(config.title.replace(/s$/i, ''))}
      </button>
    </div>

    ${rows || '<p>No records yet. Add the first record when ready.</p>'}
  `;

  target.querySelector('[data-add]')?.addEventListener(
    'click',
    async () => {
      const data = askFields(config);

      if (!data) return;

      try {
        await addDoc(collection(db, config.key), {
          ...data,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });

        toast('Record added.');
        await renderCollection(config);
      } catch (error) {
        console.error(error);
        toast(error.message);
      }
    }
  );

  const triggerIds = {
    students: 'open-add-student-modal',
    candidates: 'open-add-candidate-modal',
    positions: 'open-add-position-modal',
    elections: 'open-add-election-modal',
    securityRules: 'open-add-rule-modal'
  };

  const existingTrigger = $(triggerIds[config.key]);

  if (existingTrigger) {
    existingTrigger.onclick = () => {
      target.querySelector('[data-add]')?.click();
    };
  }

  target.querySelectorAll('[data-edit]').forEach(button => {
    button.addEventListener('click', async () => {
      const current = records.find(
        record => record.id === button.dataset.edit
      );

      if (!current) return;

      const data = askFields(config, current);

      if (!data) return;

      try {
        await updateDoc(
          doc(db, config.key, current.id),
          {
            ...data,
            updatedAt: serverTimestamp()
          }
        );

        toast('Record updated.');
        await renderCollection(config);
      } catch (error) {
        console.error(error);
        toast(error.message);
      }
    });
  });

  target.querySelectorAll('[data-delete]').forEach(button => {
    button.addEventListener('click', async () => {
      const current = records.find(
        record => record.id === button.dataset.delete
      );

      if (!current) return;

      const recordName =
        current.name ||
        current.title ||
        current.studentId ||
        'this record';

      if (!confirm(`Delete ${recordName}?`)) {
        return;
      }

      try {
        await deleteDoc(doc(db, config.key, current.id));

        if (config.key === 'students' && current.studentIdKey) {
          await deleteDoc(
            doc(db, 'studentIds', current.studentIdKey)
          );
        }

        toast('Record deleted.');
        await renderCollection(config);
      } catch (error) {
        console.error(error);
        toast(error.message);
      }
    });
  });
}

function setupNavigation() {
  document.querySelectorAll('[data-view]').forEach(button => {
    button.addEventListener('click', () => {
      document.querySelectorAll('.view-section').forEach(section => {
        section.classList.remove('active');
      });

      document.querySelectorAll('.nav-item[data-view]').forEach(item => {
        item.classList.remove('active');
      });

      $(`view-${button.dataset.view}`)?.classList.add('active');
      button.classList.add('active');
    });
  });

  $('top-profile-chip')?.addEventListener('click', () => {
    document.querySelector('[data-view="profile"]')?.click();
  });

  $('sidebar-toggle')?.addEventListener('click', () => {
    $('sidebar')?.classList.toggle('open');
  });

  $('notif-btn')?.addEventListener('click', () => {
    $('notif-dropdown')?.classList.toggle('hidden');
  });

  $('logout-btn')?.addEventListener('click', async () => {
    try {
      await signOut(auth);
      window.location.replace(LOGIN_PATH);
    } catch (error) {
      console.error(error);
      toast('Unable to log out.');
    }
  });
}

function showProfile() {
  const name =
    adminProfile?.name ||
    auth.currentUser?.displayName ||
    'Administrator';

  if ($('admin-name')) {
    $('admin-name').textContent = name;
  }

  if ($('admin-avatar')) {
    $('admin-avatar').textContent = name
      .split(/\s+/)
      .map(part => part[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();
  }

  if ($('welcome-first-name')) {
    $('welcome-first-name').textContent = name.split(' ')[0];
  }

  if ($('dash-admin-fullname')) {
    $('dash-admin-fullname').textContent = name;
  }

  if ($('profile-container')) {
    $('profile-container').innerHTML = `
      <h3>${escapeHtml(name)}</h3>
      <p>${escapeHtml(auth.currentUser?.email || '')}</p>
      <p>Administrator account verified by Firebase.</p>
    `;
  }
}

async function startAdmin(user) {
  // The admin document ID must be the authenticated user's UID.
  const adminSnap = await getDoc(doc(db, 'admins', user.uid));

  if (
    !adminSnap.exists() ||
    adminSnap.data().role !== 'admin'
  ) {
    await signOut(auth);
    window.location.replace(LOGIN_PATH);
    return;
  }

  adminProfile = adminSnap.data();

  showProfile();
  setupNavigation();

  for (const config of collectionConfig()) {
    await renderCollection(config);
  }

  const countIds = [
    ['students', 'stat-total-students'],
    ['candidates', 'stat-total-candidates']
  ];

  for (const [key, id] of countIds) {
    const snapshot = await getDocs(collection(db, key));

    if ($(id)) {
      $(id).textContent = snapshot.size;
    }
  }
}

onAuthStateChanged(auth, async user => {
  if (!user) {
    window.location.replace(LOGIN_PATH);
    return;
  }

  try {
    await startAdmin(user);
  } catch (error) {
    console.error('Admin portal error:', error);
    toast('Could not load administrator data. Check Firestore Rules and internet connection.');
  }
});
